// SPDX-License-Identifier: MIT
pragma solidity ^0.8.7;

contract Wisdomstorage{
    // int boolean, uint, address, byte
    // four more basic type are above
    //boolean defines true or false 
    //address defines 
    //varables are holders for different values

    bool Wantmoney = true;
    uint256 Mantmoney = 123;
    string Takemoney = "that is a string";
    int136 Takemoney_int = 2;
    address Heraddress = 0xdb43692221eF94964F46C8d84c1497771572D5a1;
     bytes16 Nameyour = "is it true?";

    // this code above can run but you cant see it because before you see any code on the blockchain you have to et it to public view 

    // without speciffying naything its atomatically zero 
    //functions below
    // we have four functions visibility specifiers that is 
    // 1.public 2.private 3.internal 4.External
    // uint is just like saing its a varable and also function is also use to call a varable
    // the reason why we have that under score down there in that wisdom codes its to differentiate it from the main variable 
    // what does scope means basically scope means where a variable or function can be accessed from.
    // The view keyword is used for functions that only read the blockchain but don’t change any data.
    // an array is a data structure that holds a list of other types
    // array can also act as a varable  but the difference is that its has its on bracket that is [] so u use it when ever you want to start any varable or array example person[] then you continue what you want to do 

    uint112 public  Wisdomcode;
    // lydia public person = lydia ({Wisdomcode: 5, name: "wisdom1"});
    // lydia public person2 = lydia ({Wisdomcode: 5, name: "wisdom2"});
    // lydia public person3 = lydia ({Wisdomcode: 5, name: "wisdom3"});
    // lydia public person4 = lydia ({Wisdomcode: 5, name: "wisdom4"});
    // lydia public person5 = lydia ({Wisdomcode: 5, name: "wisdom5"});

    struct lydia{
        uint112 Wisdomcode;
        string name;
    }

    // function made(uint112 _Wisdomcode) public {
    //     Wisdomcode = _Wisdomcode;
    // }

    // uint120 public Nigeria;
    // function vibe( uint120 information) public{
    //     Nigeria = information;
    // }

    // function manage () public view returns (uint120){
    //     return Nigeria;
    // } 

    // lydia[] public john;


    // uint[] firstValue = [3];

    // function getfirstvalue(uint num) public {
    //     firstValue[0] =  num;
    // }

    // uint[] SecondValue = [3];

    // function getsecondvalue(uint num) public {
    //     SecondValue[0]= num;
    // }
   
    // function Addition() public view returns (uint){
    //     return firstValue[0] + SecondValue[0];
    // }

    // function substraction() public view returns (uint){
    //     return firstValue[0] - SecondValue[0];
    // }
    


    uint[] firstValue = [2];

    function getfirstValue (uint num) public {
     firstValue[6] = num;
}  
 
    uint[] seconddvalue = [2];

    function getsecondvalue (uint num) public {
        seconddvalue[3] = num;
    }

    function Addition() public view returns (uint){
        return  firstValue [5] + seconddvalue [6];
    }

     function subtraction() public view returns (uint){
        return  firstValue [5] - seconddvalue [6];
    }


     function multiplication() public view returns (uint){
        return  firstValue [5] * seconddvalue [6];
    }


     function division() public view returns (uint){
        return  firstValue [5] / seconddvalue [6];
    }

    //There are six places you can store data in solidity 1. stack 2. memory 3. storage 4. calldata 5. code 6. logs 
    // link token contracts
    // EVM means ethereum virtual machine 

    // contract will have a blockchain but you can use the same blockchain with different codes and it will work that way
    
}