// SPDX-License-Identifier: MIT
pragma solidity   0.8.26;

contract Simple {
  
    uint[] firstValue = [3];
    
    function getFirstVal(uint num) public {
         firstValue[0] = num;
    }

    uint[] secondValue = [5];

    function getSecondval(uint num) public {
        secondValue[0] = num;
    }
   
 
    function Addition() public view returns (uint){
        return firstValue[0] + secondValue [0];
    }

    function multiplication() public view returns (uint){
        return firstValue[0] * secondValue [0];
    }

     function division() public view returns (uint){
        return firstValue[0] / secondValue [0];
    }

     function subtraction() public view returns (uint){
        return firstValue[0] - secondValue [0];
    }
   
    uint[10] array= [10, 20, 30, 40, 50, 60, 70, 80, 90];

    function deletearray() public{
    delete array[4];
    }




    // function getArrayLength() public {Person};
    
    struct Person {
        string personName;  
        uint favour;
    }
    
   Person[] public persons;

    function add(string memory _personName, uint _personAge) public {
        persons.push(Person(_personName, _personAge)); 
  } 

  uint256 favouritenumber;


    }

    

    